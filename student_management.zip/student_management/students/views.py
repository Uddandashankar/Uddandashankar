from django.shortcuts import render, redirect, get_object_or_404
from .models import Student, Attendance, Grade
from .forms import StudentForm, AttendanceForm, GradeForm

# Existing views ...

def attendance_list(request):
    attendances = Attendance.objects.all()
    return render(request, 'students/attendance_list.html', {'attendances': attendances})

def attendance_add(request):
    if request.method == 'POST':
        form = AttendanceForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('attendance_list')
    else:
        form = AttendanceForm()
    return render(request, 'students/attendance_form.html', {'form': form})

def grades_list(request):
    grades = Grade.objects.all()
    return render(request, 'students/grades_list.html', {'grades': grades})

def grades_add(request):
    if request.method == 'POST':
        form = GradeForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('grades_list')
    else:
        form = GradeForm()
    return render(request, 'students/grades_form.html', {'form': form})
