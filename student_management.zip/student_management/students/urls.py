from django.urls import path
from .views import student_list, student_add, student_edit, student_delete
from .views import attendance_list, attendance_add, grades_list, grades_add

urlpatterns = [
    path('', student_list, name='student_list'),
    path('add/', student_add, name='student_add'),
    path('edit/<int:student_id>/', student_edit, name='student_edit'),
    path('delete/<int:student_id>/', student_delete, name='student_delete'),
    path('attendance/', attendance_list, name='attendance_list'),
    path('attendance/add/', attendance_add, name='attendance_add'),
    path('grades/', grades_list, name='grades_list'),
    path('grades/add/', grades_add, name='grades_add'),
]
